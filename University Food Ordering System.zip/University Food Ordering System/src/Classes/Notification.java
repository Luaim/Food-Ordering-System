
package Classes;

import java.io.*;
import java.util.*;


public class Notification 
{
    private String name;
    private String message;
    // Constructor to initialize the Notification object
    public Notification(String name, String message)
    {
        this.name = name;
        this.message = message;
    }

    // Getter and Setter methods
    public String getName() 
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }


    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message) 
    {
        this.message = message;
    }
    // Method to get a list of user names from the Notification file
    public List<String> getusersname()
    {
        List<String> usersname = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Notification.txt")))
        {
            String line;
            
            while((line = br.readLine()) != null)
            {
                if(line.startsWith("Name:"))
                {
                    usersname.add(line.substring("Name:".length()).trim());
                }
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        return usersname;
    }
    
    // this Method to get user messages based in the user name and Notification file path
    public List<String> getUserMessages(String userName, String messagesFilePath) 
    {
        List<String> userMessages = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Notification.txt"))) 
        {
            String line;
            
            while ((line = br.readLine()) != null)
            {
                if (line.startsWith("Name:" + userName))
                {
                    line = br.readLine();
                    if (line != null)
                    {
                        userMessages.add(line.substring("Message:".length()).trim());
                    }
                }
            }
        }
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        return userMessages;
    }
    // this Method to send a message to Receipt file
     public void sendMessage(String userName, String userMessage) 
     {
        String Notification  = "C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Receipt.txt";
         
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(Notification, true)))  
        {
            writer.write("Name: " + userName.trim());
            writer.newLine();
            writer.write("Message: " + userMessage.trim());
            writer.newLine();
            writer.newLine();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
     }
}
