package Classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CloseOrder {
    
    public CloseOrder(){
        
        
        
        
    }
     
    public void CloseOrder(int Num) throws FileNotFoundException, IOException{
        String fileName = "Order.txt";
        String tempFileName = "TempOrder.txt";
        
        
        int timer = 0;
        
            try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
                
            String line;
            boolean Updated = false;
            
            
            while ((line = br.readLine()) != null) {
                
                if (timer == Num){
                  Updated = true;
                  line = br.readLine();
                  line = br.readLine();
                  line = br.readLine();
                  line = br.readLine();
                  
                  
                  
                  timer++;
                  
                }
                else{
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                // Write non-deleted lines to the temporary file
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                
                timer++;
                }
            }

            if (!Updated) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }
    }
    
    java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    
    }
    
    
}
      