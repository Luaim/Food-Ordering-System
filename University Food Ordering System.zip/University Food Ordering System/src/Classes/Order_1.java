
package Classes;

import java.time.LocalDate;


public class Order_1 {
    private String orderId;
    private String status;

    public Order_1(String orderId, String status, int parseInt, String par2, String par3, LocalDate date) {
        this.orderId = orderId;
        this.status = status;
    }

    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}

