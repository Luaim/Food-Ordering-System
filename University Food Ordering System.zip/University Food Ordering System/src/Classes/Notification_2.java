
package Classes;

import java.io.*;
import java.util.*;


public class Notification_2 
{
    private String name;
    private String message;
    
    public Notification_2(String name, String message)
    {
        this.name = name;
        this.message = message;
    }
    
    public Notification_2(){}

    public String getName() 
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }


    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message) 
    {
        this.message = message;
    }
    
    
    public List<String> getusersname()
    {
        List<String> usersname = new ArrayList<>();

    File file = new File("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Notification.txt");
    if (!file.exists()) {
        System.err.println("Notification file not found at: " + file.getAbsolutePath());
        return usersname; // Return an empty list if the file doesn't exist
    }

    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
        String line;

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) {
                continue;
            }
            String[] keyValue = line.split(":");
            if (keyValue.length >= 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();

                if (key.equals("name")) {
                    usersname.add(value);
                }
            } else {
                System.err.println("Incorrect line format: " + line);
            }
        }
    } catch (IOException e) {
        System.err.println("Error reading Notification file: " + e.getMessage());
    }
    return usersname;
        
     
     

    }
    
    
    
    
}
