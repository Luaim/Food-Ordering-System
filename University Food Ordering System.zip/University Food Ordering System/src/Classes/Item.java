
package Classes;

public class Item{
    private String Name;
    private Double Price;
    private String Description;
    
    
    
    public Item (String Name, Double Price, String Description)
    {
        this.Name = Name;
        this.Price = Price;
        this.Description = Description;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public Double getPrce() {
        return Price;
    }

    public void setPrce(Double Prce) {
        this.Price = Prce;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }
    
    public String UpdateItem()
    { 
        
        return this.Name + "," + this.Price + "," + this.Description +",";
    
    
    }
}
