
package Classes;
import java.time.LocalDate;

public class OrderUser {
        private String user;
        private String orderDetails;
        private int paid;
        private String status;
        private String vendor;
        private LocalDate date;

        public OrderUser (String user, String orderDetails, int paid, String status, String vendor, LocalDate date) {
            this.user = user;
            this.orderDetails = orderDetails;
            this.paid = paid;
            this.status = status;
            this.vendor = vendor;
            this.date = date;
        }

        // Getters for all fields...
        public String getUser() { return user; }
        public String getOrderDetails() { return orderDetails; }
        public int getPaid() { return paid; }
        public String getStatus() { return status; }
        public String getVendor() { return vendor; }
        public LocalDate getDate() { return date; }
    }



