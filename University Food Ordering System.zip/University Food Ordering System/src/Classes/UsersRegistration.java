package Classes;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import java.io.*;

//this represents the table model for managing users 
//and here extend to AbstractTableModel for the table function
public class UsersRegistration extends AbstractTableModel
{
    // this Array holding column names for the table
    private String[]columnNames = {"Name", "Email", "Contact", "Password", "UserType"};
    private List<Users> users;//this List to store user data
    
    // constructor to get  the user list and reading data from a file
    public UsersRegistration()
    {
        this.users = new ArrayList<>();
        readFromFile();
    }
    
    public UsersRegistration(List<Users> users)
    {
        this.users = users;
    }
    // this Overridden method to get the number of columns in the table
    @Override
    public int getColumnCount()
    {
        return columnNames.length;
    }
    
    // this Overridden method to get the name of a specific column
    @Override
    public String getColumnName(int column)
    {
        return columnNames[column];
    }
    
    // this Overridden method to get the number of rows in the table
    @Override
    public int getRowCount()
    {
        return users.size();
    }
    
    // this Overridden method to get the class of a specific column
    @Override
    public Class getColumnClass(int column)
    {
        return String.class;
    }
    
    // Overridden method to determine if a cell is editable
    @Override
    public boolean isCellEditable(int row, int column)
    {
        return false;
    }
    
    // this Method to read user data from a file and show the user list
    public void readFromFile()
    {
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt"))) 
        {
            List<Users> loadedUsers = new ArrayList<>();
            String line;
            
            Users user = null;
            while ((line = br.readLine()) != null)
            {
                if (line.trim().isEmpty())
                {
                    continue;
                }
                
                String[] keyValue = line.split(":");
                if (keyValue.length >= 2)
                {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    
                    if (key.equals("Name")) 
                    {
                        user = new Users("", "", "", "", "");
                        loadedUsers.add(user);
                    }
                    
                    switch (key)
                    {
                        case "Name":
                            user.setName(value);
                            break;
                        case "Email":
                            user.setEmail(value);
                            break;
                        case "Contact":
                            user.setContact(value);
                            break;
                        case "Password":
                            user.setPassword(value);
                            break;
                        case "Role":
                            user.setUserType(value);
                            break;
                    }
                }
            }
            this.users = loadedUsers;
            fireTableDataChanged();// this to Notify listeners that the table data has changed
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    // this Overridden method to get the value at a specific cell in the table
    @Override
    public Object getValueAt(int row, int column)
    {
        Users user = users.get(row);
        
        switch(column)
        {
            case 0:
                return user.getName();
            case 1:
                return user.getEmail();
            case 2:
                return user.getContact();
            case 3:
                return user.getPassword();
            case 4:
                return user.getUserType();
            default:
                return null; // Default return value
        }
    }
    // this Method to write user data to a file
    public void writeToFile()
    {
        try(BufferedWriter  wr = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt")))
        {
            for(Users user : users)
            {
                wr.write("Name:" + user.getName());
                wr.newLine();
                wr.write("Email:" + user.getEmail());
                wr.newLine();
                wr.write("Contact:" + user.getContact());
                wr.newLine();
                wr.write("Password:" + user.getPassword());
                wr.newLine();
                wr.write("Role:" + user.getUserType());
                wr.newLine();
                wr.newLine();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    // this Method to add a new user to the user list
    public void addUser(Users user)
    {
        if(users != null)
        {
            users.add( user);
            writeToFile();
            fireTableDataChanged();
            
            // this i used it to add the user balanc as default 0.0 when adding new customer only 
            if("customer".equalsIgnoreCase(user.getUserType()))
            {
                writeUserBalanceToFile(user.getName(), 0.0); 
            }
        }
    }
    
    // this Method to write customer balance information to a file
    public void writeUserBalanceToFile(String userName, double balance)
    {
        try (BufferedWriter wr = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt", true)))
        {
           wr.write("Name: " + userName);
           wr.newLine();
           wr.write("Balance: " + balance);
           wr.newLine();
           wr.newLine();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    // Method to insert a user at a specific row in the table
    public void insertUsers(int row, Users user)
    {
        users.add(row, user);
        fireTableRowsInserted(row, row);
    }
    
    // Method to remove a user from the user list and update the table
    public void removePerson(int row)
    {
        Users removedUser = users.get(row);
        
        // this also for the customerBalance if the customer have been deleted remove it also from the CustomerBalance file
        if ("customer".equalsIgnoreCase(removedUser.getUserType()))
        {
            removeCustomerBalanceEntry(removedUser.getName());
        }
        
        users.remove(row);
        writeToFile();
        fireTableDataChanged();
    }
    
    private void removeCustomerBalanceEntry(String userName)
    {
        List<String> newLines = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt")))
        {
            String line;
            boolean skipNextLine = false;
            
            while ((line = br.readLine()) != null) 
            {
                if (line.trim().isEmpty())
                {
                    continue;
                }
                String[] keyValue = line.split(":");
                
                if (keyValue.length >= 2)
                {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    
                    if (key.equals("Name") && value.equals(userName))
                    {
                        skipNextLine = true;
                        continue;
                    }
                    if(skipNextLine)
                    {
                        skipNextLine = false;
                        continue;
                    }
                }
                newLines.add(line);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        try (BufferedWriter wr = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt")))
        {
            for (String newLine : newLines)
            {
                wr.write(newLine);
                wr.newLine();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }   
    
    public Users getPerson(int row)
    {
        return users.get(row);
    }
    
    public void setUsers(List<Users> users)
    {
        this.users = users;
        fireTableDataChanged();
    }
    
    public List<Users> getUsers()
    {
        return users;
    }
    
    public void updateData(List<Users> newData)
    {
        this.users = newData;
        fireTableDataChanged();
    }
    
    public void updateUser(int row, Users updatedUser) 
    {
         Users originalUser = users.get(row);
         users.set(row, updatedUser);
         writeToFile();
         
         if("customer".equalsIgnoreCase(originalUser.getUserType()))
         {
             updateCustomerBalanceFile(originalUser.getName(), updatedUser.getName());
         }
         fireTableRowsUpdated(row, row);
    }
    
    private void updateCustomerBalanceFile(String oldName, String newName)
    {
         List<String> newLines = new ArrayList<>();
         
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt")))
        {
            String line;
            
            while ((line = br.readLine()) != null) 
            {
                if (line.trim().isEmpty())
                {
                    continue;
                }
                String[] keyValue = line.split(":");
                
                if (keyValue.length >= 2)
                {
                    String key = keyValue[0].trim();
                    String value = keyValue[1].trim();
                    
                    if (key.equals("Name") && value.equals(oldName))
                    {
                        newLines.add("Name: " + newName);    
                    }
                    else if(key.equals("Balance"))
                    {
                        newLines.add(line);
                    }
                    else
                    {
                        newLines.add(line);
                    }
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
        try (BufferedWriter wr = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt")))
        {
            for (String newLine : newLines)
            {
                wr.write(newLine);
                wr.newLine();
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
