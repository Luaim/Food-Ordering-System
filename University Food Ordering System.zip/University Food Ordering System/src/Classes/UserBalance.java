package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UserBalance {
    private String balance;

    public UserBalance(String userName) throws IOException {
        this.balance = readUserBalance(userName);
    }

    private String readUserBalance(String userName) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("Name:") && line.split(":")[1].trim().equals(userName)) {
                    String balanceLine = br.readLine(); // The next line should contain the balance
                    if (balanceLine != null && balanceLine.startsWith("Balance:")) {
                        return balanceLine.split(":")[1].trim();
                    }
                }
            }
        }
        return "0.0"; // Default balance if not found or an error occurred
    }

    public String getBalance() {
        return balance;
    }
}
