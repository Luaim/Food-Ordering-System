/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author arlen
 */
public class OrderController implements VendorInterface{
    
    String email;
    int rownum;
    public OrderController(Order OrderDet, Vendor name){
        this.email = name.getEmail();
        this.rownum = OrderDet.getRownum();
    }
    public OrderController(int row, Vendor name){
        this.email = name.getEmail();
        this.rownum = row;
    }
    public OrderController(Vendor name){
        this.email = name.getEmail();
    
    }
    @Override
    public void ReadToTable(DefaultTableModel model) throws FileNotFoundException {
        
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt"))) {
            String line;
            String User;
            String Order;
            String Paid;
            String Status;
            String Vendor;
            String[] columns = new String[4];
            while ((line = br.readLine()) != null)
            {
                
                if (line.startsWith("User:")) 
                {
                    User = line.substring(5).trim();
                    line = br.readLine();
                    Order = line.substring(7).trim();
                    line = br.readLine();
                    Paid = line.substring(5).trim();
                    line = br.readLine();
                    Status = line.substring(7).trim();
                    line = br.readLine();
                    Vendor = line.substring(7).trim();
                    
                    columns[0] = User;
                    columns[1] = Order;
                    columns[2] = Paid;
                    columns[3] = Status;
                    
                    
                    if(Vendor.equals(email)){
                    
                         model.addRow(columns);
                    }
                    
                } 
            }
        } catch (IOException e) {
            
        }
       
    }

    
    

    @Override
    public void AddNewData(String Name, String Price, String Details) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    @Override
    public void DeleteData(String Name, String email) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    @Override
    public void UpdateTextFile(String ItemName, Item NewItem, String email) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void OrderPending() throws FileNotFoundException, IOException{
    
        String fileName = "Order.txt";
        String tempFileName = "TempOrder.txt";
        
        int timer = 0;
        double amount;
        String name;
        
            try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            String line;
            boolean Updated = false;

            while ((line = br.readLine()) != null) {
                
                if (timer == rownum){
                  Updated = true;
                  bw.write(line);
                  bw.newLine(); 
                  name = line.substring(5);
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  amount = Double.parseDouble(line.substring(5));
                  
                  line = br.readLine();
                  line = "Status:Preparing";
                  bw.write(line);
                  bw.newLine();
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  CustomerBal cb = new CustomerBal(name,amount);
                  System.out.println(amount);
                  cb.CutomerBalence();
                  timer++;
                  
                }
                else{
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                // Write non-deleted lines to the temporary file
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                timer++;
                }
            }

            if (!Updated) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }
    }
    
    java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    
    
    
                
    }
    
   
   public void OrderStatus() throws FileNotFoundException, IOException{
       String fileName = "Order.txt";
        String tempFileName = "TempOrder.txt";
        
        int timer = 0;
        
            try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            String line;
            boolean Updated = false;

            while ((line = br.readLine()) != null) {
                
                if (timer == rownum){
                  Updated = true;
                  bw.write(line);
                  bw.newLine(); 
                  
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  
                  
                  line = br.readLine();
                  line = "Status:Wating for pick up";
                  bw.write(line);
                  bw.newLine();
                  
                  line = br.readLine();
                  bw.write(line);
                  bw.newLine();
                  
                  timer++;
                  
                }
                else{
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                // Write non-deleted lines to the temporary file
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                timer++;
                }
            }

            if (!Updated) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }
    }
    
    java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                
                
                
    
    } 
   
    public void OrderPickedup() throws FileNotFoundException, IOException{
    String fileName = "Order.txt";
        String tempFileName = "TempOrder.txt";
        FileWriter newfw = new FileWriter("FinishedOrders.txt", true);
        BufferedWriter newbw = new BufferedWriter(newfw);
        int timer = 0;
        
            try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
                
            String line;
            boolean Updated = false;
            String[] FinishedOrder = new String[5];
            
            while ((line = br.readLine()) != null) {
                
                if (timer == rownum){
                  Updated = true;
                  FinishedOrder[0] = line.substring(5).trim();
                  line = br.readLine();
                  FinishedOrder[1] = line.substring(7).trim();
                  line = br.readLine();
                  FinishedOrder[2] = line.substring(5).trim();
                  line = br.readLine();
                  FinishedOrder[3] = "Finished";
                  line = br.readLine();
                  FinishedOrder[4] = line.substring(7).trim();
                  
                  LocalDate date = LocalDate.now();
                  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                  String CurrentDate = date.format(formatter);
                  newbw.write(FinishedOrder[0]+","+FinishedOrder[1]+","+FinishedOrder[2]+","+FinishedOrder[3]+","+FinishedOrder[4]+","+CurrentDate);
                  newbw.newLine();
                  newbw.close();
                  newfw.close();
                  timer++;
                  
                }
                else{
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                // Write non-deleted lines to the temporary file
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                timer++;
                }
            }

            if (!Updated) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }
    }
    
    java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    
    }
    public void ViewReviews(DefaultTableModel model){
    try (BufferedReader br = new BufferedReader(new FileReader("Review.txt"))) {
            String line;
            String User;
            String Order;
            String Review;
            String Vendor;
            String[] columns = new String[3];
            while ((line = br.readLine()) != null)
            {
                if (line.startsWith("User:")) 
                {
                    User = line.substring(5).trim();
                    line = br.readLine();
                    Order = line.substring(7).trim();
                    line = br.readLine();
                    Review = line.substring(7).trim();
                    line = br.readLine();
                    Vendor = line.substring(7).trim();
                    
                    columns[0] = User;
                    columns[1] = Order;
                    columns[2] = Review;
                    
                    
                    
                    if(Vendor.equals(email)){
                    
                         model.addRow(columns);
                    }
                } 
            }
        } catch (IOException e) {
        }
  } 
}
