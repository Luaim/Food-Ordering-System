package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;


public class UpdateProfile //Class fields
{
    private String loggedInEmail;
    private String loggedInPassword;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtPassword;

    
    private Map<String, String> userInfo = new HashMap<>();
    
    // Constructor
    public UpdateProfile(String email, String password, javax.swing.JTextField txtEmail, javax.swing.JTextField txtName, javax.swing.JTextField txtContact, javax.swing.JTextField txtPassword)
    {
        this.loggedInEmail = email;
        this.loggedInPassword = password;
        this.txtEmail = txtEmail;
        this.txtName = txtName;
        this.txtContact = txtContact;
        this.txtPassword = txtPassword;
        
        readUserInfoFromFile();// this for Read user information from file for the objective created
    }
    
    private void readUserInfoFromFile()// for reading the info from the file
    {
        boolean foundUser = false;
        try(BufferedReader re = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt")))
        {
            String line;
            while((line = re.readLine()) != null)
            {
                String[] parts = line.split(":");
                if(parts.length == 2)
                {
                    userInfo.put(parts[0], parts[1]);
                }
                
                // this for checking if the email and password exist
                if(userInfo.containsKey("Email") && userInfo.containsKey("Password") && userInfo.get("Email").equals(loggedInEmail) && userInfo.get("Password").equals(loggedInPassword))
                {
                    foundUser = true;
                    break;
                }
            }
            
            if(foundUser)//this if the user found update the user info
            {
                String name = userInfo.get("Name");
                String contact = userInfo.get("Contact");
                String password = userInfo.get("Password");
                
                txtName.setText(name);
                txtEmail.setText(loggedInEmail);
                txtContact.setText(contact);
                txtPassword.setText(password);
            }
            else
            {
                userInfo.clear();
            }
            
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
    
    // those are the Getter  methods    
    public String getName()
    {
        return userInfo.get("Name");
    }
    
    public String getEmail()
    {
       return userInfo.get("Email");
    }
    
    public String getContact()
    {
       return userInfo.get("Contact");
    }
    
    public String getPassword()
    {
       return userInfo.get("Password");
    }
    
    // this method for updateing the admin profile
    public void updateProfile(String name, String email, String contact, String password)
    {
        List<String> updatedUserLines = new ArrayList<>();
        boolean isCurrentUser = false;
        
        try(BufferedReader re = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt")))
        {
            String line;
            boolean updated = false;
            
            while ((line = re.readLine()) != null)
            {
                String[] parts = line.split(":");
                
                if(parts.length == 2)
                {
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    
                    // this for checking if the line match the login info
                    if (key.equals("Email") && value.equals(loggedInEmail))
                    {
                        isCurrentUser = true;
                        
                        // this for skipping the four line becuse those will be replaced
                        re.readLine();
                        re.readLine();
                        re.readLine();
                        re.readLine();
                            
                        // those to Add updated information to the file
                        updatedUserLines.add("Name:" + name);
                        updatedUserLines.add("Email:" + email);
                        updatedUserLines.add("Contact:" + contact);
                        updatedUserLines.add("Password:" + password);
                        updatedUserLines.add("Role:admin");
                        updatedUserLines.add("");
                        
                        updated = true;
                    } 
                    else // this to add line 
                    {
                        updatedUserLines.add(line);
                    }
                }
                else
                {
                    updatedUserLines.add(line);
                }
            }
            
            if(!updated && isCurrentUser)// this is to check if the user have not updated and add the new info
            {
                updatedUserLines.add("Name:" + name);
                updatedUserLines.add("Email:" + email);
                updatedUserLines.add("Contact:" + contact);
                updatedUserLines.add("Password:" + password);
                updatedUserLines.add("Role:admin");
                updatedUserLines.add("");
            }
        }
        catch(IOException e)
        {
           e.printStackTrace();
        }
       
        // this for writing the info to the file   
       try(FileWriter wr = new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt"))
        {        
            for(String updatedLine : updatedUserLines)
            {
               wr.write(updatedLine + "\n");
            }
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
