/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class HistoryController implements VendorInterface{
    String email;
    public HistoryController(String name) {
        this.email = name;
    }

    @Override
    public void ReadToTable(DefaultTableModel model) throws FileNotFoundException {
        FileReader fw = new FileReader("FinishedOrders.txt");
    BufferedReader bw = new BufferedReader(fw);

    String firstLine;
        try {
            firstLine = bw.readLine();
            if (firstLine != null) {
        String[] columnsName = firstLine.trim().split("/");
        
        model.setColumnIdentifiers(columnsName);
              
        Object[] tableLines = bw.lines().toArray();

        // extract data from lines
        // set data to jtable model
        for (Object tableLine : tableLines) {
            String line = tableLine.toString().trim();
            
            String[] dataRow = line.split(",");
            if (dataRow[4].equals(email)){
                model.addRow(dataRow);
            }
            
        }
    }

    bw.close(); // don't forget to close the BufferedReader
    fw.close();
       
        } catch (IOException ex) {
            Logger.getLogger(HistoryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
       
       
        
    }

    @Override
    public void AddNewData(String Name, String Price, String Details) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void DeleteData(String Name, String email) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void UpdateTextFile(String ItemName, Item NewItem, String email) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
