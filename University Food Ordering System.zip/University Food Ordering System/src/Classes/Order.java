/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author arlen
 */
public class Order {
    private String Order;
    private String Status;
    private Double paid;
    private String User;
    private int rownum;
    
    public Order(String User, String Order, String Status, Double paid, int rownum){
        this.Order = Order;
        this.Status = Status;
        this.paid = paid;
        this.User = User;
        this.rownum = rownum;
    }
    public Order(String name){
        this.User = name;
    }

   
    public String getOrder() {
        return Order;
    }

    
    public void setOrder(String Order) {
        this.Order = Order;
    }

    
    public String getStatus() {
        return Status;
    }

    
    public void setStatus(String Status) {
        this.Status = Status;
    }

    
    public Double getPaid() {
        return paid;
    }

   
    public void setPaid(Double paid) {
        this.paid = paid;
    }

    
    public String getUser() {
        return User;
    }

    
    public void setUser(String User) {
        this.User = User;
    }

    /**
     * @return the rownum
     */
    public int getRownum() {
        return rownum;
    }

    /**
     * @param rownum the rownum to set
     */
    public void setRownum(int rownum) {
        this.rownum = rownum;
    }
    
}
