package Classes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class RevenueManager {
    private JTable revenueTable;
    private JComboBox<String> sortingComboBox;
    private List<Order> orders;

    public RevenueManager(JTable revenueTable, JComboBox<String> sortingComboBox) {
        this.revenueTable = revenueTable;
    this.sortingComboBox = sortingComboBox;
    this.orders = new ArrayList<>();
    loadRevenues();
    updateRevenueTable();
    }

    private void loadRevenues() {
        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\FinishedOrders.txt"))) {
            String line;
            reader.readLine(); 
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    // Assume structure: User,Order,Paid,Status,Vendor,Date
                    String user = parts[0].trim();
                    String orderItem = parts[1].trim();
                    double paid = Double.parseDouble(parts[2].trim());
                    String status = parts[3].trim();
                    String vendor = parts[4].trim();
                    Date date = dateFormat.parse(parts[5].trim());
                    orders.add(new Order(user, orderItem, paid, status, vendor, date));
                }
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        updateRevenueTable(); 
    }

    private void updateRevenueTable() {
        DefaultTableModel model = (DefaultTableModel) revenueTable.getModel();
        model.setRowCount(0); 
        for (Order order : orders) {
            model.addRow(new Object[] { order.getUser(), order.getOrderItem(), order.getPaid(), order.getStatus(), order.getVendor(), order.getDate() });
        }
    }

    public void sortRevenues(String period) {
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Calendar cal = Calendar.getInstance();
        cal.setTime(now);
        List<Order> sortedOrders = null;

        switch (period) {
        case "Daily":
           
            break;
        case "Weekly":
            Calendar startOfWeek = Calendar.getInstance();
            startOfWeek.set(Calendar.DAY_OF_WEEK, startOfWeek.getFirstDayOfWeek());
            sortedOrders = orders.stream()
                    .filter(o -> o.getDate().after(startOfWeek.getTime()) && o.getDate().before(now))
                    .collect(Collectors.toList());
            break;
        case "Monthly":
            Calendar startOfMonth = Calendar.getInstance();
            startOfMonth.set(Calendar.DAY_OF_MONTH, 1);
            sortedOrders = orders.stream()
                    .filter(o -> o.getDate().after(startOfMonth.getTime()) && o.getDate().before(now))
                    .collect(Collectors.toList());
            break;
        case "Yearly":
            Calendar startOfYear = Calendar.getInstance();
            startOfYear.set(Calendar.DAY_OF_YEAR, 1);
            sortedOrders = orders.stream()
                    .filter(o -> o.getDate().after(startOfYear.getTime()) && o.getDate().before(now))
                    .collect(Collectors.toList());
            break;
        default:
            sortedOrders = new ArrayList<>(orders); 
            break;
    }

    updateRevenueTable(sortedOrders);
}

private void updateRevenueTable(List<Order> sortedOrders) {
    SwingUtilities.invokeLater(new Runnable() {
        public void run() {
            DefaultTableModel model = (DefaultTableModel) revenueTable.getModel();
            model.setColumnIdentifiers(new Object[] {"User", "Order Item", "Paid", "Status", "Vendor", "Date"});
            model.setRowCount(0); 
            for (Order order : sortedOrders) {
                model.addRow(new Object[] {
                    order.getUser(),
                    order.getOrderItem(),
                    order.getPaid(),
                    order.getStatus(),
                    order.getVendor(),
                    new SimpleDateFormat("dd-MM-yyyy").format(order.getDate())
                });
            }
        }
    });
    }


    
    // Inner class to represent an order
    private static class Order {
        private String user;
        private String orderItem;
        private double paid;
        private String status;
        private String vendor;
        private Date date;

        public Order(String user, String orderItem, double paid, String status, String vendor, Date date) {
            this.user = user;
            this.orderItem = orderItem;
            this.paid = paid;
            this.status = status;
            this.vendor = vendor;
            this.date = date;
        }

        // Getters
        public String getUser() { return user; }
        public String getOrderItem() { return orderItem; }
        public double getPaid() { return paid; }
        public String getStatus() { return status; }
        public String getVendor() { return vendor; }
        public Date getDate() { return date; }
    }
}
