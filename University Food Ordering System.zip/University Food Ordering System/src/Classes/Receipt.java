package Classes;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Receipt 
{
    private String customerName;
    private List<ReceiptItem> items;
    // constructor
    public Receipt()
    {
        items = new ArrayList<>();
    }
    // constructor with customer name to get the customer name  
    public Receipt(String customerName) 
    {
        this.customerName = customerName;
        items = new ArrayList<>();
    }
    // this is the Method is used to  add an item to the receipt
    public void addItem(String itemID, String itemName, double price, int quantity) 
    {
        ReceiptItem item = new ReceiptItem(itemID, itemName, price, quantity);
        items.add(item);
    }
    // this method is used to get the data for the reciept
    public String getCurrentDate() 
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        return dateFormat.format(date);
    }
    // this to get the time for the reciept
    public String getCurrentTime() 
    {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        return timeFormat.format(date);
    }
    // those are the Getter and Setter methods 
    public String getCustomerName() 
    {
        return customerName;
    }

    public void setCustomerName(String customerName) 
    {
        this.customerName = customerName;
    }
    // this Method to calculate the total cost of items in the receipt
    public double calculateTotal() 
    {
        double total = 0.0;
        for (ReceiptItem item : items) 
        {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }
    // this Method to generate a formatted receipt
    public String generateReceipt() 
    {
        StringBuilder r = new StringBuilder();

        r.append("=====================================\n");
        r.append("                   University Food Ordering\n");
        r.append("                               System\n");
        r.append(" Date: ").append(getCurrentDate()).append("                           Time: ").append(getCurrentTime()).append("\n");
        r.append("=====================================\n");
        r.append("Customer: ").append(customerName).append("\n\n");
        r.append(String.format("%-9s %-20s %-20s %-5s\n", "Item ID", "Item Name", "Quantity", "Price"));
        
        double totalPrice = 0.0;
        
        for (ReceiptItem item : items)
        {
            double itemTotalPrice = item.getPrice() * item.getQuantity();
            r.append(String.format("%-15s %-28s %-14d %-1.2f RM\n", item.getItemID(), item.getItemName(), item.getQuantity(), itemTotalPrice));
            totalPrice += itemTotalPrice;
        }

        r.append("\n");
        r.append(String.format("%-65s%-2.2f RM\n", "Total:", totalPrice));
        r.append("=====================================\n");
        r.append("                    Have a great day! \n");
        r.append("       If you have any questions or concerns \n");
        r.append("            please feel free to contact us. \n");
        r.append("          support@universityfoodorders.com \n");

        return r.toString();
    }
    // this is the Inner class representing a receipt item
    private static class ReceiptItem 
    {
        private String itemID;
        private String itemName;
        private double price;
        private int quantity;
        
        // Constructor for a receipt item
        public ReceiptItem(String itemID, String itemName, double price, int quantity) 
        {
            this.itemID = itemID;
            this.itemName = itemName;
            this.price = price;
            this.quantity = quantity;
        }
        // Getter methods for receipt item 
        public String getItemID() 
        {
            return itemID;
        }

        public String getItemName() 
        {
            return itemName;
        }

        public double getPrice() 
        {
            return price;
        }

        public int getQuantity() 
        {
            return quantity;
        }
    }
}
