
package Classes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class TaskRequestManager {
    private JTable jTable2; 
    private DefaultTableModel tableModel;
    private List<Order> orderList;
    private JButton jButton2; 
    private JButton jButton3; 
    private JButton jButton5; 
    private JButton jButton6; 
    private JScrollPane jScrollPane3; 
    private JPanel pnlRequest;
    private final Path Order = Paths.get("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt");

    public TaskRequestManager(
        DefaultTableModel tableModel,
    JButton jButton2, JButton jButton3,
    JScrollPane jScrollPane3, JPanel pnlRequest) {

    this.jTable2 = new JTable(tableModel); 
    this.tableModel = tableModel;
    this.jScrollPane3 = jScrollPane3;
    this.pnlRequest = pnlRequest;
    this.orderList = new ArrayList<>();
    this.jButton2 = jButton2;
    this.jButton3 = jButton3;


        setupButtonActions();
    }

    
    class Order {
        String user;
        String orders;
        String paid;
        String status;
        String vendor;

        public Order(String user, String orders, String paid, String status, String vendor) {
            this.user = user;
            this.orders = orders;
            this.paid = paid;
            this.status = status;
            this.vendor = vendor;
        }
    }

    public void loadOrdersForRunner(String Order) {
        tableModel.setRowCount(0); 
        orderList.clear(); 

        try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String user = line.substring(line.indexOf(':') + 1);
                String orders = reader.readLine().split(":")[1];
                String paid = reader.readLine().split(":")[1];
                String status = reader.readLine().split(":")[1].trim();
                String vendor = reader.readLine().split(":")[1];

                // Check for status "waiting for runner"
                if ("Waiting for pick up".equalsIgnoreCase(status)) {
                    Order order = new Order(user, orders, paid, status, vendor);
                    orderList.add(order);
                    tableModel.addRow(new Object[]{user, orders, vendor}); 
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setupButtonActions() {
        jButton2.addActionListener(e -> acceptOrder(jTable2.getSelectedRow()));
        jButton3.addActionListener(e -> declineOrder(jTable2.getSelectedRow()));
    }

    private void acceptOrder(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < orderList.size()) {
            Order order = orderList.get(orderIndex);
            tableModel.removeRow(orderIndex);
        }
    }

    private void declineOrder(int orderIndex) {
        if (orderIndex >= 0 && orderIndex < orderList.size()) {
            Order order = orderList.get(orderIndex);
            tableModel.removeRow(orderIndex);
        }
    }  
}
    
    
