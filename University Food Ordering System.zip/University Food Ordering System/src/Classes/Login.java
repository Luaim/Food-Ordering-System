package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Login 
{
    // Method to authenticate user based on email and password
    public String authenticateUser(String email, String password) 
    {
        try 
        {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt"));
            String Email = null;
            String Password = null;
            String role = null;
            String line;
            
            while ((line = br.readLine()) != null)//checking user information from the file
            {
                if (line.startsWith("Email:")) 
                {
                    Email = line.substring(6).trim();
                } 
                else if (line.startsWith("Password:")) 
                {
                    Password = line.substring(9).trim();
                } 
                else if (line.startsWith("Role:")) 
                {
                    role = line.substring(5).trim();
                }
                
                 // Check if the  email and password that the user put it match
                if (Email != null && Password != null && role != null) 
                {
                    if (email.equals(Email) && password.equals(Password)) 
                    {
                        br.close();
                        return role;// Return the user role (admin, vendor, customer, runner.)
                    } 
                    Email = null;
                    Password = null;
                    role = null;
                }
            }
            br.close();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        return "Invalid email and password"; // Return message for unsuccessful log in
    }
}
