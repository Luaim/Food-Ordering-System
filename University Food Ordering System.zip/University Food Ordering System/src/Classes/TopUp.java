
package Classes;

import javax.swing.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class TopUp 
{
   private final String customerBalanceFilePath; 
   
   public TopUp(String customerBalanceFilePath)// Constructor to initialize the customer balance file path
   {
       this.customerBalanceFilePath = customerBalanceFilePath;
   }
   // this is the Method to get a list of user names from the customer balance file
   public List<String> getUserNames() 
   {
       List<String> userNames = new ArrayList<>();
       
       try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\CustomerBalance.txt")))
       {
           String line;
           
           while ((line = br.readLine()) != null)
           {
               if (line.trim().isEmpty()) 
               {
                   continue;
               }
               String[] keyValue = line.split(":");
               
               if (keyValue.length >= 2)
               {
                   String key = keyValue[0].trim();
                   String value = keyValue[1].trim();
                   
                   if (key.equals("Name")) 
                   {
                       userNames.add(value);
                   }
               }
           }
       } 
       catch (IOException e) 
       {
           e.printStackTrace();
       }
       return userNames;
   }
   // this Method to perform a balance top-up for a given user
   public void topUpBalance(String Recipient, double topUpAmount)
   {
       double currentBalance = getCurrentBalance(Recipient);
       
       if(currentBalance != -1)
       {
           double newBalance = currentBalance + topUpAmount;
           updateBalanceInFile(Recipient, newBalance);
           
           sendTopUpNotification(Recipient, newBalance);
       }
       else
       {
           JOptionPane.showMessageDialog(null, "User not found. New Balance: ", "Error", JOptionPane.ERROR_MESSAGE);
       }
   }
   // this Method to get the current balance for a selceted user
   private double getCurrentBalance(String userName)
   {
       try (BufferedReader br = new BufferedReader(new FileReader(customerBalanceFilePath)))
       {
          String line;
          
          while ((line = br.readLine()) != null) 
          {
             if (line.trim().isEmpty())
             {
                 continue;
             } 
             String[] keyValue = line.split(":");
             
             if (keyValue.length >= 2)
             {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                
                if (key.equals("Name") && value.equals(userName))
                {
                    line = br.readLine();
                    return Double.parseDouble(line.split(":")[1].trim());
                }
             } 
          }
       }
       catch (IOException e)
       {
            e.printStackTrace();  
       }
       return -1;
   }
   // this Method to update the balance in the customer balance file
   private void updateBalanceInFile(String userName, double newBalance) 
   {
       List<String> newLines = new ArrayList<>();
       
       try (BufferedReader br = new BufferedReader(new FileReader(customerBalanceFilePath))) 
       {
           String line;
           
           while ((line = br.readLine()) != null)
           {
               if (line.trim().isEmpty()) 
               {
                   continue;
               }
               String[] keyValue = line.split(":");
               
               if (keyValue.length >= 2) 
               {
                   String key = keyValue[0].trim();
                   String value = keyValue[1].trim();
                   
                   if (key.equals("Name") && value.equals(userName))
                   {
                       br.readLine();
                       
                       newLines.add("Name: " + userName);
                       newLines.add("Balance: " + newBalance);
                       
                   }
                   else
                   {
                       newLines.add(line);
                   }
               }
           }
       }
       catch (IOException e)
       {
           e.printStackTrace();
       }
       
       try (BufferedWriter wr = new BufferedWriter(new FileWriter(customerBalanceFilePath))) 
       {
            for (String newLine : newLines)
            {
                wr.write(newLine);
                wr.newLine();
            } 
       }
       catch (IOException e)
       {
           e.printStackTrace();
       }
   }
   
   public void updateUIForSelectedUser(String selectedUser, JTextField txtName2, JTextField txtBalance) 
   {
       double balance = getCurrentBalance(selectedUser);
       
       txtName2.setText(selectedUser);
       txtBalance.setText(String.valueOf(balance));
   }
   // this Method to generate a receipt for a top-up 
   public String generateReceipt(String userName, double topUpAmount)
   {
       double currentBalance = getCurrentBalance(userName);
       
       if(currentBalance != -1)
       {
           
           StringBuilder r = new StringBuilder();
           r.append("========================================\n");
           r.append("                         University Food Ordering\n");
           r.append("                                   System\n");
           r.append("\n");
           r.append(" Date: ").append(getCurrentDate()).append("                                 Time: ").append(getCurrentTime()).append("\n");
           r.append("========================================\n");
           r.append("Name                      Balance                 Top-up Amount\n");
           r.append(String.format("%-20s%-29.2f%-5.2f RM\n", userName, currentBalance, topUpAmount));
           r.append("\nTotal:").append(String.format("%65.2f RM\n", currentBalance + topUpAmount));
           r.append("========================================\n");
           r.append("                           Have a great day!\n");
           r.append("               If you have any questions or concerns\n");
           r.append("                    please feel free to contact us.\n");
           r.append("                support@universityfoodorders.com\n");
           
           return r.toString();
       }
       else
       {
          JOptionPane.showMessageDialog(null, "User not found. New Balance: ", "Error", JOptionPane.ERROR_MESSAGE);
          return null;
       }
   }
   // this to get the current date
   private String getCurrentDate() 
   {
       Date date = new Date();
       return new SimpleDateFormat("dd/MM/yyyy").format(date);
   }
   // this to get the current time
   private String getCurrentTime() 
   {
       Date date = new Date();
       return new SimpleDateFormat("hh:mm a").format(date);
   }
    // this Method is used to send a top-up notification to the customer
   private void sendTopUpNotification(String Recipient, double newBalance) 
   {
       String notificationFilePath = "C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Receipt.txt";
       
       
       try (BufferedWriter wr = new BufferedWriter(new FileWriter(notificationFilePath, true))) 
       {
           wr.write("Name:" + Recipient);
           wr.newLine();
           wr.write("Message: " + " Admin, Your balance has been topped up successfully. Your balance is " + newBalance + " RM");
           wr.newLine();
           wr.newLine();
       }
       catch (IOException e)
       {
           e.printStackTrace();
       }
   }
}
