/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author arlen
 */
public class Revenue {
    String email;
    public Revenue(String email) {
        this.email = email;
    }
    
        
    public double CountRevenue() throws FileNotFoundException, IOException{
        FileReader fw = new FileReader("FinishedOrders.txt");
        BufferedReader bw = new BufferedReader(fw);

        String firstLine = bw.readLine();
        double rev = 0 ;
        if (firstLine != null) {
            
            Object[] tableLines = bw.lines().toArray();
            
            // extract data from lines
            // set data to jtable model
            for (Object tableLine : tableLines) {
                String line = tableLine.toString().trim();

                String[] dataRow = line.split(",");
                if (dataRow[4].equals(email)){
                    
                    rev += Double.parseDouble(dataRow[2]);
                    
                }

            }
        }

    bw.close();
    fw.close();
       
    return rev;   
    }

}
