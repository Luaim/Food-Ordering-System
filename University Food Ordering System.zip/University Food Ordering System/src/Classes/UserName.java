package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UserName {
    private String userName;

    public UserName(String email) throws IOException {
        this.userName = findUserNameByEmail(email);
    }

    private String findUserNameByEmail(String email) throws IOException {
        String tempUserName = "Guest"; // Default to Guest if the user is not found
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("Name:")) {
                    tempUserName = line.split(":")[1].trim();
                }
                if (line.trim().startsWith("Email:") && line.split(":")[1].trim().equals(email)) {
                    return tempUserName;
                }
            }
        }
        return tempUserName;
    }

    public String getUserName() {
        return userName;
    }
}