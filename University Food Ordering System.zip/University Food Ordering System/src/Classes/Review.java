package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.table.DefaultTableModel;
import java.io.IOException;

public class Review {
    public DefaultTableModel loadRunnerReviews(String reviewsFilePath) {
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"User", "Orders", "Review", "Vendor"});

        try (BufferedReader br = new BufferedReader(new FileReader(reviewsFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("User:")) {
                    String user = line.substring(line.indexOf(':') + 1).trim();
                    String orders = br.readLine().split(":")[1].trim();
                    String runner = br.readLine().split(":")[1].trim();
                    String review = br.readLine().split(":")[1].trim();
                    String vendor = br.readLine().split(":")[1].trim();
                    
                        if (runner.equals(Runner.class.getName())) {  
                        model.addRow(new Object[]{user, orders, review, vendor});
                    }
                }
            }
        } catch (IOException e) {
        }

        return model;
    }

    
    

    }

    

