package Classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class History extends AbstractTableModel {
    private final List<OrderUser> orders = new ArrayList<>();
    private final String[] columnNames = {"User", "Order", "Paid", "Status", "Vendor", "Date"};

    public void loadData(String filePath) {
    orders.clear();  

    try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\FinishedOrders.txt"))) {
        String line = reader.readLine();  
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            // Assuming the date is in the format "dd-MM-yyyy"
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate date = LocalDate.parse(data[5].trim(), formatter);

            OrderUser orderUser = new OrderUser(
                data[0].trim(),  // User
                data[1].trim(),  // Order
                Integer.parseInt(data[2].trim()),  // Paid
                data[3].trim(),  // Status
                data[4].trim(),  // Vendor
                date  // Date
            );
            orders.add(orderUser);  
        }
    } catch (IOException e) {
        e.printStackTrace();
    }

    fireTableDataChanged();  
}

    @Override
    public int getRowCount() {
        return orders.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        OrderUser order = orders.get(rowIndex);
        switch (columnIndex) {
            case 0: return order.getUser();
            case 1: return order.getOrderDetails();
            case 2: return order.getPaid();
            case 3: return order.getStatus();
            case 4: return order.getVendor();
            case 5: return order.getDate().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            default: return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}