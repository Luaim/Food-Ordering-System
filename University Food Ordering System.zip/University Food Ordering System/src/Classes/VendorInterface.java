/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author arlen
 */
public interface VendorInterface {
    
    
    
    void ReadToTable(DefaultTableModel model) throws FileNotFoundException;
    
    void AddNewData(String Name, String Price, String Details);
    
    void DeleteData(String Name, String email)  throws IOException ;
    
    void UpdateTextFile(String ItemName, Item NewItem, String email) throws IOException;
    
}
