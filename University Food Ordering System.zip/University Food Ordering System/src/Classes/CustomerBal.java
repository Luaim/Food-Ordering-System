/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author arlen
 */
public class CustomerBal {
    String Name;
    Double amount;
    public CustomerBal(String name, Double amount) {
       this.Name = name;
       this.amount = amount;        
    }
    
    public void CutomerBalence() throws FileNotFoundException, IOException{
        String fileName = "CustomerBalance.txt";
        String tempFileName = "CustomerBalancetemp.txt";

        try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName);
             BufferedWriter bw = new BufferedWriter(fw)) {

            String line;
            boolean updated = false;

            while ((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();

                if (line.startsWith("Name:") && line.substring(5).trim().equals(Name)) {
                    // Found the user, update the balance
                    double curBal = Double.parseDouble(br.readLine().substring(8));
                    curBal -= amount;

                    line = "Balance:" + curBal;
                    bw.write(line);
                    bw.newLine();
                    updated = true;
                }
                else{
                    
                line = br.readLine();
                bw.write(line);
                bw.newLine();
                
                
                }
            }

            if (!updated) {
                System.out.println("User not found for balance update.");
            } else {
                System.out.println("Balance updated successfully.");
            }
        }

        // Move the temporary file to replace the original file
        java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName),
                java.nio.file.Paths.get(fileName), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }
}

