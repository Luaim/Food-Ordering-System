package Classes;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

public class OrderManagementSystem {

    private JTable jTable1;
    private JComboBox<String> jComboBox1;
    private JComboBox<String> jComboBox2;
    private JButton jButton1;
    private DefaultTableModel tableModel;
    private final Path Order = Paths.get("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt");

    public OrderManagementSystem() {
        initializeComponents();
        loadOrdersFromFile();
        setupComboBoxes();
        setupUpdateButton();
        
        
    }

    public void initializeComponents() {
        jTable1 = new JTable();
        jComboBox1 = new JComboBox<>();
        jComboBox2 = new JComboBox<>(new String[]{"On Delivery", "Delivered"});
        jButton1 = new JButton("Update");
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Users");
        tableModel.addColumn("Orders");
        tableModel.addColumn("Vendor");
        jTable1.setModel(tableModel);
    }

    
    public void loadOrdersFromFile() {
        tableModel.setRowCount(0);
        jComboBox1.removeAllItems();

        try (BufferedReader reader = Files.newBufferedReader(Order)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("User:")) {
                    String user = line.substring(5);
                    String orders = reader.readLine().substring(7);
                    String paid = reader.readLine().substring(5);
                    String status = reader.readLine().substring(7);
                    String vendor = reader.readLine().substring(7);
                    if (status.equals("Waiting for pick up") || status.equals("on delivery")) {
                        tableModel.addRow(new Object[]{user, orders, vendor});
                        jComboBox1.addItem(orders);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setupComboBoxes() {

    }

    public void setupUpdateButton() {
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String selectedOrder = (String) jComboBox1.getSelectedItem();
                String newStatus = (String) jComboBox2.getSelectedItem();
                updateOrderStatus(selectedOrder, newStatus);
            }
        });
    }

    public void updateOrderStatus(String orderId, String newStatus) {
 
        List<String> fileContent = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(Order)) {
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.add(line);
                if (line.contains("Orders:" + orderId)) {           
                    fileContent.add(reader.readLine());
                    fileContent.add("Status:" + newStatus);
                    reader.readLine(); 
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Write the new content back to the file
        try (BufferedWriter writer = Files.newBufferedWriter(Order)) {
            for (String contentLine : fileContent) {
                writer.write(contentLine);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public JTable getJTable1() {
        return jTable1;
    }

    public JComboBox<String> getJComboBox1() {
        return jComboBox1;
    }

    public JComboBox<String> getJComboBox2() {
        return jComboBox2;
    }

    public JButton getJButton1() {
        return jButton1;
    }
}

