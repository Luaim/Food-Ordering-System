/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author arlen
 */
public class ItemController implements VendorInterface{
    String email;
    public ItemController(Vendor vendor){
        this.email = vendor.getEmail();
    }

    @Override
    public void ReadToTable(DefaultTableModel model) throws FileNotFoundException {
        FileReader fw = new FileReader("Items.txt");
        BufferedReader bw = new BufferedReader(fw);

        String firstLine;
        try {
            firstLine = bw.readLine();
            if (firstLine != null) {
        String[] columnsName = firstLine.trim().split("/");
        
        model.setColumnIdentifiers(columnsName);
              
        Object[] tableLines = bw.lines().toArray();

        // extract data from lines
        // set data to jtable model
        for (Object tableLine : tableLines) {
            String line = tableLine.toString().trim();
            
            String[] dataRow = line.split(",");
            if (dataRow[3].equals(email)){
                model.addRow(dataRow);
            }
            
        }
    }

    bw.close(); // don't forget to close the BufferedReader
    fw.close();
        } catch (IOException ex) {
            Logger.getLogger(ItemController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     
   }

    @Override
    public void AddNewData(String Name, String Price, String Details) {
        FileWriter fw;
        try {
            fw = new FileWriter("Items.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            String NewItem[] = new String[4];
            NewItem[0] = Name;
            NewItem[1] = Price;
            NewItem[2] = Details;
            NewItem[3] = email;
        
            bw.append(NewItem[0]+","+NewItem[1]+","+NewItem[2]+","+NewItem[3]+"\n");
        
        
        bw.close();
        fw.close();
        } catch (IOException ex) {
            Logger.getLogger(ItemController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    @Override
    public void DeleteData(String Name, String email) throws IOException  {
        String fileName = "Items.txt";
        String tempFileName = "TempItems.txt";

        try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            String line;
            boolean deleted = false;

            while ((line = br.readLine()) != null) {
                String[] dataRow = line.split(",");

                // Check conditions for deletion (adjust as needed)
                if (dataRow.length >= 4 && dataRow[3].equals(email) && dataRow[0].equals(Name)) {
                    deleted = true;
                    continue; // Skip writing the line for deletion
                }

                // Write non-deleted lines to the temporary file
                bw.write(line);
                bw.newLine();
            }

            if (!deleted) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }

        } catch (IOException e) {
        }

        // Replace the original file with the temporary file
        java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    
    @Override
    public void UpdateTextFile(String ItemName, Item NewItem, String email) throws IOException {
        String fileName = "Items.txt";
        String tempFileName = "TempItems.txt";

        try (FileReader fr = new FileReader(fileName);
             BufferedReader br = new BufferedReader(fr);
             FileWriter fw = new FileWriter(tempFileName, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            String line;
            boolean deleted = false;

            while ((line = br.readLine()) != null) {
                String[] dataRow = line.split(",");

                // Check conditions for deletion (adjust as needed)
                if (dataRow.length >= 4 && dataRow[3].equals(email) && dataRow[0].equals(ItemName)) {
                    deleted = true;

                    line = NewItem.UpdateItem() +email;
                }

                // Write non-deleted lines to the temporary file
                bw.write(line);
                bw.newLine();
            }

            if (!deleted) {
                System.out.println("Item not found for deletion.");
            } else {
                System.out.println("Item deleted successfully.");
            }

        } catch (IOException e) {
        }

        // Replace the original file with the temporary file
        java.nio.file.Files.move(java.nio.file.Paths.get(tempFileName), java.nio.file.Paths.get(fileName),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }
    
    
    
}

    
    

   
    

