
package Classes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Runner{
    
    private String email;
    private String password;
    String Name;
    
    public Runner() {
  
    }
    public Runner(String email, String password) {
        this.email= email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     *
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public String Getname() throws FileNotFoundException, IOException{
        FileReader fr = new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Users.txt");
        BufferedReader br = new BufferedReader(fr);
        String line;
            String Name = "";
            String User;
            String Email;
            String Contact;
            String Password;
            String Role;
            String[] columns = new String[5];
            while ((line = br.readLine()) != null)
            {
                
                if (line.startsWith("Name:")) 
                {
                    User = line.substring(5).trim();
                    line = br.readLine();
                    Email = line.substring(6).trim();
                    line = br.readLine();
                    Contact = line.substring(8).trim();
                    line = br.readLine();
                    Password = line.substring(9).trim();
                    line = br.readLine();
                    Role = line.substring(5).trim();
                    
                    columns[0] = User;
                    columns[1] = Email;
                    columns[2] = Contact;
                    columns[3] = Password;
                    columns[4] = Role;
                    
                    
                    if(Email.equals(email)){
                    
                         System.out.println(columns[0]);
                         Name = columns[0];
                    }
                    
                } 
            }
        
        
        return Name;
        
    }
    public void PasswordChange(){
        
        
        
        
        
    }

}
 

        
    
            
        
    
    

