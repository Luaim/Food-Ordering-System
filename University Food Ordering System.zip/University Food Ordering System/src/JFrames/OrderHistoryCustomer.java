package JFrames;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class OrderHistoryCustomer extends javax.swing.JFrame {

    
    
    private Customer customerWindow;
    private String userName;

    public OrderHistoryCustomer(Customer customer, String userName) {
        this.customerWindow = customer;
        this.userName = userName;
        initComponents();
        loadOrderHistory();
    }
    


    public OrderHistoryCustomer() {
        initComponents();
    }
    

    private void loadOrderHistory() {
    DefaultTableModel model = (DefaultTableModel) tblOrder.getModel();
    model.setRowCount(0);

    try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt"))) {
        String line;
        String user = "";
        String orders = "";
        String paid = "";
        String status = "";
        String vendor = "";
        
        
        while ((line = br.readLine()) != null) {
            if (line.startsWith("User:")) {
                user = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Orders:")) {
                orders = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Paid:")) {
                paid = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Status:")) {
                status = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Vendor:")) {
                vendor = line.substring(line.indexOf(":") + 1).trim();
                if (user.equals(userName) && status.equals("Delivered")) {
                    model.addRow(new Object[]{vendor, orders, paid, status});
                }

                user = "";
                orders = "";
                paid = "";
                status = "";
                vendor = "";
                
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbOrderHistory = new javax.swing.JLabel();
        btnReorder = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOrder = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        btnReview = new javax.swing.JButton();
        txtReview = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbOrderHistory.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbOrderHistory.setText("Order History");

        btnReorder.setText("Reorder");
        btnReorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReorderActionPerformed(evt);
            }
        });

        tblOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Vendor", "Ordered", "Price", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblOrder);

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnReview.setText("Review");
        btnReview.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReviewActionPerformed(evt);
            }
        });

        txtReview.setText("Write review on selected order");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtReview, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnReview, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(57, 57, 57)
                                .addComponent(btnReorder, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbOrderHistory)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lbOrderHistory)
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtReview, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReview, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBack)
                .addGap(20, 20, 20))
            .addGroup(layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(btnReorder, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        if (customerWindow != null) {
        customerWindow.setVisible(true);
        }
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnReorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReorderActionPerformed
        // Get the selected row from the table
    int selectedRow = tblOrder.getSelectedRow();
    if (selectedRow >= 0) {
        // Extract the order details
        String vendor = tblOrder.getValueAt(selectedRow, 0).toString();
        String orders = tblOrder.getValueAt(selectedRow, 1).toString();
        String paid = tblOrder.getValueAt(selectedRow, 2).toString();

        // Write the reorder to the Orders.txt file with status set to "Pending"
        writeReorderToFile(userName, orders, paid, vendor, "Pending");
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "Please select an order to reorder.");
    }
    }//GEN-LAST:event_btnReorderActionPerformed

    private void btnReviewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReviewActionPerformed
        int selectedRow = tblOrder.getSelectedRow();
        String reviewText = txtReview.getText().trim();
        if (selectedRow != -1 && !reviewText.isEmpty()) {
            String vendor = tblOrder.getValueAt(selectedRow, 0).toString();
            String orders = tblOrder.getValueAt(selectedRow, 1).toString();

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Review.txt", true))) {
                writer.write("User:" + userName);
                writer.newLine();
                writer.write("Vendor:" + vendor);
                writer.newLine();
                writer.write("Orders:" + orders);
                writer.newLine();
                writer.write("Review:" + reviewText);
                writer.newLine();

                JOptionPane.showMessageDialog(this, "Review submitted successfully!");
                txtReview.setText("");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error submitting the review.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order and write a review.");
        }
    }//GEN-LAST:event_btnReviewActionPerformed

    private void writeReorderToFile(String user, String orders, String paid, String status, String vendor) {
    String filePath = "C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt";
    System.out.println("Writing to file: " + filePath); // Add this line for debugging

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
        writer.write("User:" + user);
        writer.newLine();
        writer.write("Orders:" + orders);
        writer.newLine();
        writer.write("Paid:" + paid);
        writer.newLine();
        writer.write("Status:Pending");
        writer.newLine();
        writer.write("Vendor:" + vendor);
        writer.newLine();
        
        javax.swing.JOptionPane.showMessageDialog(this, "Reorder placed successfully.");
    } catch (IOException e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error placing reorder.");
    }
}
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderHistoryCustomer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnReorder;
    private javax.swing.JButton btnReview;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbOrderHistory;
    private javax.swing.JTable tblOrder;
    private javax.swing.JTextField txtReview;
    // End of variables declaration//GEN-END:variables
}
