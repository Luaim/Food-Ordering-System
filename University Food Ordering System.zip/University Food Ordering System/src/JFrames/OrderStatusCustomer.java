package JFrames;

import Classes.CloseOrder;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class OrderStatusCustomer extends javax.swing.JFrame {

     private Customer customerWindow;
     private String userName;


    public OrderStatusCustomer(Customer customer, String userName) {
        this.customerWindow = customer;
        this.userName = userName;
        initComponents();
        loadOrderHistory();
    }
    
private void loadOrderHistory() {
    DefaultTableModel model = (DefaultTableModel) tblOrder.getModel();
    model.setRowCount(0);

    try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt"))) {
        String line;
        String user = "";
        String orders = "";
        String paid = "";
        String status = "";
        String vendor = "";
        
        
        while ((line = br.readLine()) != null) {
            if (line.startsWith("User:")) {
                user = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Orders:")) {
                orders = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Paid:")) {
                paid = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Status:")) {
                status = line.substring(line.indexOf(":") + 1).trim();
            } else if (line.startsWith("Vendor:")) {
                vendor = line.substring(line.indexOf(":") + 1).trim();

                
                if (user.equals(userName) && status.equals("Pending")) {
                    model.addRow(new Object[]{vendor, orders, status});
                }

                user = "";
                orders = "";
                paid = "";
                status = "";
                vendor = "";
                
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    public OrderStatusCustomer() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbOrderStatus = new javax.swing.JLabel();
        btnCloseOrder = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOrder = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbOrderStatus.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lbOrderStatus.setText("Order Status");

        btnCloseOrder.setText("Close Order");
        btnCloseOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseOrderActionPerformed(evt);
            }
        });

        tblOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Vendor", "Orders", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblOrder);

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCloseOrder))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lbOrderStatus)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lbOrderStatus)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCloseOrder)
                    .addComponent(btnBack))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseOrderActionPerformed
           
        int rownum = tblOrder.getSelectedRow();
        
        CloseOrder co = new CloseOrder();
         try {
             co.CloseOrder(rownum);
         } catch (IOException ex) {
             Logger.getLogger(OrderStatusCustomer.class.getName()).log(Level.SEVERE, null, ex);
         }
        this.dispose();
        OrderStatusCustomer ok = new OrderStatusCustomer(customerWindow,userName);
        ok.setVisible(true);
        
                   
    }//GEN-LAST:event_btnCloseOrderActionPerformed


    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        if (customerWindow != null) {
        customerWindow.setVisible(true);
        }
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderStatusCustomer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCloseOrder;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbOrderStatus;
    private javax.swing.JTable tblOrder;
    // End of variables declaration//GEN-END:variables
}
