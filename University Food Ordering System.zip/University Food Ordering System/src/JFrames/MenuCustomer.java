package JFrames;

import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MenuCustomer extends javax.swing.JFrame {

    private String userName;
    private Customer customerWindow;

    public MenuCustomer(Customer customer, String userName) {
        this.customerWindow = customer;
        this.userName = userName;
        initComponents();
        loadMenuItems();
}
    
    public MenuCustomer() {
        initComponents();
        loadMenuItems();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBackMenu = new javax.swing.JButton();
        lbMenu = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMenu = new javax.swing.JTable();
        btnOrder = new javax.swing.JButton();
        lbOrder = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnBackMenu.setText("Back");
        btnBackMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackMenuActionPerformed(evt);
            }
        });

        lbMenu.setText("MENU");

        tblMenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Price", "Desc", "Vendor"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblMenu);

        btnOrder.setText("Order");
        btnOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderActionPerformed(evt);
            }
        });

        lbOrder.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        lbOrder.setText("Enter items");
        lbOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbOrderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBackMenu)
                    .addComponent(lbMenu)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnOrder)
                            .addComponent(lbOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lbMenu)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnOrder)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(btnBackMenu)
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackMenuActionPerformed

    if (customerWindow != null) {
        customerWindow.setVisible(true);
    }
    this.dispose();
    }//GEN-LAST:event_btnBackMenuActionPerformed

    private void lbOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbOrderActionPerformed

    }//GEN-LAST:event_lbOrderActionPerformed

    private void btnOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderActionPerformed
    String orderedItemName = lbOrder.getText().trim();
    DefaultTableModel model = (DefaultTableModel) tblMenu.getModel();
    boolean orderSuccess = false;
    
    for (int i = 0; i < model.getRowCount(); i++) {
        Object itemObject = model.getValueAt(i, 0);
        if (itemObject != null && itemObject.toString().equalsIgnoreCase(orderedItemName)) {
            
            // If item name matches, retrieve the price and vendor.
            String itemPrice = model.getValueAt(i, 1) != null ? model.getValueAt(i, 1).toString() : "Unknown";
            String vendorName = model.getValueAt(i, 3) != null ? model.getValueAt(i, 3).toString() : "Unknown";
            
            saveOrderToFile(orderedItemName, itemPrice, vendorName);
            javax.swing.JOptionPane.showMessageDialog(this, "Order successful!");
            orderSuccess = true;
            break;
        }
    }
    
    if (!orderSuccess) {
        javax.swing.JOptionPane.showMessageDialog(this, "Item not found: " + orderedItemName);
    }
}
    
    private void saveOrderToFile(String itemName, String paidAmount, String vendorName) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Order.txt", true))) {
        writer.write("User:" + userName);
        writer.newLine();
        writer.write("Orders:" + itemName);
        writer.newLine();
        writer.write("Paid:" + paidAmount);
        writer.newLine();
        writer.write("Status:Pending");
        writer.newLine();
        writer.write("Vendor:" + vendorName);
        writer.newLine();
        
    } catch (IOException e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnOrderActionPerformed

    private void loadMenuItems() {
        DefaultTableModel model = (DefaultTableModel) tblMenu.getModel();
        model.setRowCount(0); // Clear the table
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Downloads\\Compressed\\University Food Ordering System\\Items.txt"))) {
            br.readLine(); 
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 4) {
                    model.addRow(new Object[]{data[0].trim(), data[1].trim(), data[2].trim(), data[3].trim()});
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
     private String welcomeMessage;
   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuCustomer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackMenu;
    private javax.swing.JButton btnOrder;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbMenu;
    private javax.swing.JTextField lbOrder;
    private javax.swing.JTable tblMenu;
    // End of variables declaration//GEN-END:variables
}
