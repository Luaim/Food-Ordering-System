package JFrames;

import Classes.UserBalance;
import Classes.UserName;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Customer extends javax.swing.JFrame {
    private UserName userName;
    private UserBalance userBalance;

    
    public Customer(String email, String password) throws IOException {
        initComponents();

        this.userName = new UserName(email);
        this.userBalance = new UserBalance(userName.getUserName());

        lbWelcomeCustomer.setText("Welcome, " + userName.getUserName());
        lbBalanceCustomer.setText("Balance: RM" + userBalance.getBalance());
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCheckOrderHistoryCustomer = new javax.swing.JButton();
        btnViewMenuCustomer = new javax.swing.JButton();
        btnBalance = new javax.swing.JButton();
        btnLogOut = new javax.swing.JButton();
        lbWelcomeCustomer = new javax.swing.JLabel();
        lbNotification = new javax.swing.JButton();
        btnOrderStatus = new javax.swing.JButton();
        lbBalanceCustomer = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnCheckOrderHistoryCustomer.setText("Order History");
        btnCheckOrderHistoryCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckOrderHistoryCustomerActionPerformed(evt);
            }
        });

        btnViewMenuCustomer.setText("View Menu");
        btnViewMenuCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewMenuCustomerActionPerformed(evt);
            }
        });

        btnBalance.setText("Balance");
        btnBalance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBalanceActionPerformed(evt);
            }
        });

        btnLogOut.setText("Log Out");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        lbWelcomeCustomer.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lbNotification.setText("Notification");
        lbNotification.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbNotificationActionPerformed(evt);
            }
        });

        btnOrderStatus.setText("Order Status");
        btnOrderStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderStatusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbWelcomeCustomer)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbNotification, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnCheckOrderHistoryCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                    .addComponent(btnOrderStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 142, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBalance, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnLogOut, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbBalanceCustomer, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addComponent(btnViewMenuCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(25, 25, 25))))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCheckOrderHistoryCustomer, btnOrderStatus});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(lbWelcomeCustomer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(btnViewMenuCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnOrderStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbBalanceCustomer)
                            .addComponent(btnCheckOrderHistoryCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(lbNotification, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(111, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnBalance, btnCheckOrderHistoryCustomer, btnOrderStatus, btnViewMenuCustomer});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnViewMenuCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewMenuCustomerActionPerformed
        MenuCustomer menuCustomer = new MenuCustomer(this, this.userName.getUserName());

        this.setVisible(false);

        menuCustomer.setVisible(true);
    }//GEN-LAST:event_btnViewMenuCustomerActionPerformed

    private void btnCheckOrderHistoryCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckOrderHistoryCustomerActionPerformed
        OrderHistoryCustomer orderHistoryCustomer = new OrderHistoryCustomer(this, this.userName.getUserName());

        this.setVisible(false);

        orderHistoryCustomer.setVisible(true);
    }//GEN-LAST:event_btnCheckOrderHistoryCustomerActionPerformed

    private void lbNotificationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbNotificationActionPerformed
        NotificationCustomer notificationCustomer = new NotificationCustomer(this, this.userName.getUserName());

        this.setVisible(false);

        notificationCustomer.setVisible(true);
    }//GEN-LAST:event_lbNotificationActionPerformed

    private void btnBalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBalanceActionPerformed
        BalanceCustomer balanceCustomer = new BalanceCustomer(this, this.userName.getUserName()); // Pass 'this' as the Customer window reference

        this.setVisible(false); // Hide the Customer window

        balanceCustomer.setVisible(true);

    }//GEN-LAST:event_btnBalanceActionPerformed

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        Login login = new Login();

        this.setVisible(false);

        login.setVisible(true);
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnOrderStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderStatusActionPerformed
        OrderStatusCustomer orderStatusCustomer = new OrderStatusCustomer(this, this.userName.getUserName());

        this.setVisible(false);

        orderStatusCustomer.setVisible(true);
    }//GEN-LAST:event_btnOrderStatusActionPerformed


    
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                try {
                    new Customer("jonathon@gmail.com", "123").setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBalance;
    private javax.swing.JButton btnCheckOrderHistoryCustomer;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnOrderStatus;
    private javax.swing.JButton btnViewMenuCustomer;
    private javax.swing.JLabel lbBalanceCustomer;
    private javax.swing.JButton lbNotification;
    private javax.swing.JLabel lbWelcomeCustomer;
    // End of variables declaration//GEN-END:variables
}
